let klient = {
    imie : null,
    nazwisko : null,
    wiek :null ,
    zgoda_marketingowa: null,
}
imie = window.prompt("twoje imie mooordeczko")
nazwisko = window.prompt("wpisz swoje naaazwisko moordunio normalnie")
wiek = window.prompt("tu wpisz sowj lvl")

zgoda_marketingowa = window.confirm("mooordeczko wyraz zgode")
window.alert("mefedron to szmata suki nie chce znac hhhtfu jebac moze z kurwa rusze jesli zajedzie potrzeba a na razie to to zlewam hhhh jebac czego sie spodziewal ze tutaj zgine pu pu pu nie ten rocznik skurwysynie farszem nabijam cukinie jesli bit bylby cukinia ding dong nie pojedziesz ta winda zagrasz w ping pong to kurwa odbij lubisz plotki ty moj chuj jest slodki twoje ruchy to mzonki twoje ziomki to pionki przeciwko nam kurwa rzadowe czolgi czujesz sie spokojny to pewnie zyjesz w bledzie czujesz niespokojnie to pewnie masz wyjete pare nocy z rzedu przegrywasz z wielodobem zasypiasz pierdolic cpunskie fobie tfu jade z tym jakbym kurwa jechal z dziwka Polska Warszawa ciemna strefa hip-hop macie cos przeciwko to mamy bif na noze dobry boze ja pierdole co za mlodziez to sie rap to sie woze chuj mnie boli co se napiszesz na forze jointy smorze woila madam ty kurwa taka ze bys smyrnal po posladach takie tutaj sobie wypierdalam a ty w populizmach sie upierdalaj dzyn dzyn co tam morda u ciebie ebe ebe ebe ebe ebe i bardzo dobrze to nie gluchy telefon idz pokrzycz do lasu to uslyszysz echo echo satelita wysoko namierza twoj telefon logowania helo moto wez ogarnij cos by nie wiedzial o tym nikt ze sciany maja uszy wiadomo nie od dzis sasiedzi zle intencje zawodzi czynnik ludzki tak jak bydle leci do garnka wodki potega gotowki nie chce skonczyc jak reszta z reszta znowu wypada reszka jebana dilerka wrozby z bialego prochu wybierz jedna liczbe od dziesieciu do roku atmosfera gesta co raz bardziej w butli exclusive rich bitch kupuja futra z nutrii putry kasyna hotele zabawa jebnie ci pikawa trwa zawal la vida la vada ladnie zes naklamal sad cie uniewinnia bo sam tego nie ogarnia to nie kurwa narnia choc tysiace bajek cuda-wianki pioropusze kaszel od ruskich fajek kyhy kyhy tiri titi MELINIARSKO KURWA DEWASTACYJNE GRAFITI!")
